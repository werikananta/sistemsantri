<?php
$nama_lengkap = "Weri Ekananta";
$status = "Aktif";
$kelas_mutqin = "Kelas Tasri";
$tanggal_lahir = "2025-04-29";
$alamat = "sadfasdf";
$nomor_id = "RQ-423";
$nomor_hp = "085333691939";
$foto_profil = "https://5tb.my.id/beta/kerangka/uploads/profil-nabil.png";
$tanda_tangan = "https://staging.dimensy.id/assets/img/articles/mceclip017.png";
$kartu_tanda_santri = "https://www.beritariau.com/foto_berita/2022/05/2022-05-23-aturan-baru-buat-ktp-nama-maksimal-60-huruf-termasuk-spasi.b686f703";
$sertifikat = "https://marketplace.canva.com/EAFUKIJeAN8/1/0/800w/canva-merah-dan-putih-elegan-sertifikat-penghargaan-QXvp9P-HloQ.jpg";
$kelas = "2 SMP";
$berlaku_hingga = "2025-04-23";
?>